
This is a 3tawi of Great Projects Home Automation - Control relays using ESP32 Wi-Fi local webserver| Restore relay state using EEPROM.

Lien vidéo
https://youtu.be/d-_6nL-Z9UM